import mitt from 'mitt';
export const events = mitt(); // 导出一个发布订阅的对象 
